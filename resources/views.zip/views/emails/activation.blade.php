Wellcome, {{ $name }}
Please active your account : {{ url('user/activation', $link)}}
