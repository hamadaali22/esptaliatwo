Welcome, please click on this link to activate your account : {{ url('patient/activation', $link)}}
